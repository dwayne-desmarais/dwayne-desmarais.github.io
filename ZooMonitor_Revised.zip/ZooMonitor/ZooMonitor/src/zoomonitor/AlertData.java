/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitor;

/**
 *
 * @author dwayne.desmar_snhu
 * This class is used to store alert data for the dialog boxes in ZooMonitor.java
 */
public class AlertData {
    boolean alert_found;
    String alertMessage;
    String alertTitle;
    
    public void AlertData() {
        alert_found = false;
        alertMessage = "";
        alertTitle = "";
    }
    
    public void setAlert(boolean value) {
        alert_found = value;
    }
    
    public void setMessage(String message) {
        alertMessage = message;
    }

    public void setTitle(String title) {
        alertTitle = title;
    }

    public boolean getAlert() {
        return alert_found;
    }
    
    public String getMessage() {
        return alertMessage;
    }
    
    public String getTitle() {
        return alertTitle;
    }
}

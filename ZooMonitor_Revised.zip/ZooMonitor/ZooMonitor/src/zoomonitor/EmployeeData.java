/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitor;

/**
 *
 * @author dwayne.desmar_snhu
 * This is the class to store the data parsed from animal.txt within 
 * ZooMonitor.java main()
 */
public class EmployeeData {
    String position;
    String name;
    int age;
    String zone;
    String schedule;
    
    public void AnimalData() {
        position = "";
        name = "";
        age = -1;
        zone = "";
        schedule = "";
    }

    // mutator - set specified field with value
    // fields: position, name, zone, schedule
    public void setField(String field, String value) {
        switch(field) {
            case "position": {
                position = value;
                break;
            }
            case "name": {
                name = value;
                break;
            }
            case "zone": {
                zone = value;
                break;
            }
            case "schedule": {
                schedule = value;
                break;
            }
            default: {
                System.out.println("Error -> EmployeeData -> setField");
                break;
            }
        }
    }
    
    // accessor - get specified field - returns string
    // fields: position, name, zone, schedule
    public String getField(String field) {
        String strValue = "";
        
        switch (field) {
            case "position": {
                strValue = position;
                break;
            }
            case "name": {
                strValue = name;
                break;
            }
            case "zone": {
                strValue = zone;
                break;
            }
	    case "schedule": {
		strValue = schedule;
		break;
	    }
            default: {
                System.out.println("Error -> EmployeeData -> getField");
                break; 
            }
        }
        return strValue;
    }
    
    // age mutator/accessor for int values
    public void setAge(int value) {
        age = value;
    }
    
    public int getAge() {
        return age;    
    }
}

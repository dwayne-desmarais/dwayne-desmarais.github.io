/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitor;

/**
 *
 * @author dwayne.desmar_snhu
 * This class is a clone of the AnimalData class, modified to record habitat
 * data parsed from habitat.txt within ZooMonitor main()
 */
public class HabitatData {
    String habitat;
    String temp;
    String food; 
    String clean;
    AlertData alert = new AlertData(); // custom class to store alert data

    public void HabitatData() {
        habitat = "";
        temp = "";
        food = "";
        clean = "";
        alert.setAlert(false);
        alert.setMessage("Message");
        alert.setTitle("Title");
    }

    // mutator - set specified field with value
    // fields: habitat, temp, clean, food
    public void setField(String field, String value) {
        switch (field) {
            case "temp": {
                temp = value;
                break;
            }
            case "habitat": {
                habitat = value;
                break;
            }
            // records alert data info
            case "food": {
                if (value.contains("*****")) {
                    value = value.replace("*****", "");
                    alert.setAlert(true);
                    alert.setTitle("Food Source Alert");
                    alert.setMessage(value);
                }
                food = value;
                break;
            }
            // records alert data info
            case "clean": {
                if (value.contains("*****")) {
                    value = value.replace("*****", "");
                    alert.setAlert(true);
                    alert.setTitle("Cleanlisness Alert");
                    alert.setMessage(value);
                }
                clean = value;
                break;
            }
            default: {
                System.out.println("Error -> HabitatData -> setField");
                break;
            }
        }
    }

    // accessor - get specified field - returns string
    // fields: habitat, temp, clean, food
    public String getField(String field) {
        String strValue = "";

        switch (field) {
            case "temp": {
                strValue = temp;
                break;
            }
            case "habitat": {
                strValue = habitat;
                break;
            }
            case "food": {
                strValue = food;
                break;
            }
            case "clean": {
                strValue = clean;
                break;
            }
            default: {
                System.out.println("Error -> HabitatData -> getField");
                break;
            }
        }
        return strValue;
    }

    public void setAlert(boolean value) {
        alert.setAlert(value);
    }

    public boolean getAlert() {
        return alert.getAlert();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitor;

/**
 *
 * @author dwayne.desmar_snhu
 * This is the class to store the data parsed from animal.txt within 
 * ZooMonitor.java main()
 */
public class AnimalData {
    String species;
    String name;
    int age;
    String health;
    String feeding;
    AlertData alert = new AlertData();  // custom class to store alert info
    
    public void AnimalData() {
        species = "";
        name = "";
        age = -1;
        health = "";
        feeding = "";
        alert.setAlert(false);
        alert.setMessage("Message");
        alert.setTitle("Title");
    }

    // mutator - set specified field with value
    // fields: species, name, health, feeding
    public void setField(String field, String value) {
        switch(field) {
            case "species": {
                species = value;
                break;
            }
            case "name": {
                name = value;
                break;
            }
            // records alert data info
            case "health": {
                if (value.contains("*****")) {
                    value = value.replace("*****", "");
                    alert.setAlert(true);
                    alert.setTitle("Health Concern Alert");
                    alert.setMessage(value);
                }
                health = value;
                break;
            }
            // records alert data info
            case "feeding": {
                if (value.contains("*****")) {
                    value = value.replace("*****", "");
                    alert.setAlert(true);
                    alert.setTitle("Feeding Schedule Alert");
                    alert.setMessage(value);
                }
                feeding = value;
                break;
            }
            default: {
                System.out.println("Error -> AnimalData -> setField");
                break;
            }
        }
    }
    
    // accessor - get specified field - returns string
    // fields: species, name, health, feeding
    public String getField(String field) {
        String strValue = "";
        
        switch (field) {
            case "species": {
                strValue = species;
                break;
            }
            case "name": {
                strValue = name;
                break;
            }
            case "health": {
                strValue = health;
                break;
            }
            case "feeding": {
                strValue = feeding;
                break;
            }
            default: {
                System.out.println("Error -> AnimalData -> getField");
                break; 
            }
        }
        return strValue;
    }
    
    // age mutator/accessor for int values
    public void setAge(int value) {
        age = value;
    }
    
    public int getAge() {
        return age;    
    }
    
    // sets the true/false value of the alert class -> alert_found field
    public void setAlert(boolean value) {
        alert.setAlert(value);
    }

    public boolean getAlert() {
        return alert.getAlert();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitor;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.*;

/**
 *
 * @author dwayne.desmar_snhu
 */
public class ZooMonitor {

    /**
     * @param args the command line arguments
     */
    
    // menu print method, args = "main", "animal", "habitat"
    public static void printMenuPrompt(String menuOption) {
        
        switch(menuOption) {
            case "main": {
                System.out.println("What would you like to do?");
                System.out.println("(A)nimal, (H)abitat, (E)xit");
                break;
            }
            case "animal": {
                System.out.println("Enter the animal would you like to examine? (B)ack (E)xit");
                break;
            }
            case "habitat": {
                System.out.println("Enter the habitat would you like to examine? (B)ack (E)xit");
                break;
            }
            default: {
                System.out.println("Error -> printMainMenu() -> switch(menuOption)");
                break;
            }
        }
    }
    
    public static void printSubMenu(String subtype) throws IOException {
        
        FileInputStream fileByteStream = null; // File input stream
        Scanner inFS = null;
        String textToSearch; 
        
        if (subtype.equals("animal")) {
            fileByteStream = new FileInputStream("animal.txt");
            textToSearch = "Animal - ";
        }

        if (subtype.equals("habitat")) {
            fileByteStream = new FileInputStream("habitat.txt");
            textToSearch = "Habitat - ";
        }
        else {
            // default for errors with subtype entries
            fileByteStream = new FileInputStream("animal.txt");
            textToSearch = "Animal - ";
        }

        inFS = new Scanner(fileByteStream);
        String readLine1;
        String listItem; // used to create list of animal lookup options
        /**
         * While loop to parse out available animal names based on file header
         * Details on animal 1 Details on animal 2 etc.
         */
        // used to create a list of animal options to lookup
        // loops through until options are not found
        while (inFS.hasNext()) {

            readLine1 = inFS.nextLine();
            if (readLine1.contains(textToSearch)) {
                listItem = readLine1.replace(textToSearch, "");
                System.out.print(listItem + " ");
            }
        }
        
        fileByteStream.close();
    }
    // used to make sure the format of the user input matches the file data
    // when comparing string values
    public static String updateCapitalize(String value) {
        String convert;
        
        if (value == null || value.length() == 0) {
            return value;
        }
        convert = value.substring(0, 1).toUpperCase() + value.substring(1);
        return convert;
    }
    
    // main user interface and menu options - handles navigation
    // and some of the major output of the program to the user
    // also handles file access for animal.txt and habitat.txt
    public static void main(String[] args) throws IOException {
        Scanner scnr = new Scanner(System.in);
        String getUserInput = null;
        AnimalData animalInfo = new AnimalData(); // used to store animal data
        HabitatData habitatInfo = new HabitatData(); // used to store habitat data
        boolean data_found = false; // confirms AnimalData was found, breaks while loop
        String capitalizeUserInput = ""; // used with string manipulations
        String alertMessage = ""; // used for alerts
        String alertTitle = ""; // used for alerts
         
        FileInputStream fileByteStream = null; // File input stream
        Scanner inFS = null; 
        String readLine1 = null;       
       
        printMenuPrompt("main"); // multiple menu output options method
        getUserInput = scnr.next();
        
        // top level menu handling system for user interface
        while (!getUserInput.equals("E") && !getUserInput.equals("e")) {
            /*
             *  ANIMAL CODE
             */
            switch(getUserInput) {                
                case "A": 
                case "a": {
                    fileByteStream = new FileInputStream("animal.txt");
                    inFS = new Scanner(fileByteStream);
                    
                    printMenuPrompt("animal");
                
                    // Try to open animal.txt file
                    System.out.print("Available animals for review: ");
                    // used to print out sub menu options for user
                    printSubMenu("animal");

                    // line formating obtain user input for animal lookup
                    System.out.println("");
                    getUserInput = scnr.next();
                    
                    if (getUserInput.equals("B") || getUserInput.equals("b")
                     || getUserInput.equals("E") || getUserInput.equals("e")) {
                        break;
                    }

                    // cycle through file until no more lines and/or data is found
                    while (inFS.hasNext() && !data_found) {
                        
                        // set readLine1 to next line in animal.txt
                        readLine1 = inFS.nextLine();
                    
                        // format user input with capital letter for string comparison
                        capitalizeUserInput = updateCapitalize(getUserInput);
                    
                        // look for lead line of animal data in file, look for user input of animal
                        // name - compares and if found, cycles through lines filling in animalInfo
                        if (readLine1.contains("Animal - ") && readLine1.contains(capitalizeUserInput)) {
                            // if found, format Animal - xxxx line then move to next line in file
                            animalInfo.setField("species", readLine1);
                            readLine1 = inFS.nextLine();

                            animalInfo.setField("name", readLine1.replace("Name: ", ""));
                            readLine1 = inFS.nextLine();
                        
                            animalInfo.setAge(Integer.valueOf(readLine1.replace("Age: ", "")));
                            readLine1 = inFS.nextLine();
                        
                            // note this does not remove the ***** only the 'Health concerns: ' part
                            // the stars carry over to identify an alert in the AnimalData() method
                            animalInfo.setField("health", readLine1.replace("Health concerns: ", ""));
                            readLine1 = inFS.nextLine();
                        
                            animalInfo.setField("feeding", readLine1.replace("Feeding schedule: ", ""));

                            // flag data_found to exit while loop and print data to user
                            data_found = true;
                            fileByteStream.close();
                        }
                    }
                                        
                    if (animalInfo.getField("name") != null) {
                    
                        if (animalInfo.alert.alert_found) {
                            alertTitle = animalInfo.alert.getTitle();
                            alertMessage = animalInfo.alert.getMessage();
                            System.out.println("Pop up alert!");
                            JOptionPane.showMessageDialog(null, alertMessage, alertTitle, JOptionPane.INFORMATION_MESSAGE);
                            animalInfo.alert.setAlert(false);
                        }
                        // print out data to user
                        System.out.println(animalInfo.getField("species"));
                        System.out.println("Name:    " + animalInfo.getField("name"));
                        System.out.println("Age:     " + animalInfo.getAge());
                        System.out.println("Health concerns: \n   " + animalInfo.getField("health"));
                        System.out.println("Feeding schedule: \n   " + animalInfo.getField("feeding"));
                    }
                    else {
                        // FIXME: add in options to add animals to the database in the future
                        System.out.println("That animal is not currently registered in the database.");
                    }
                    // reset loop based values for additional animal lookup sequences
                    data_found = false;                 
                    getUserInput = "a";
                    break;
                }
                /*
                 *  HABITAT CODE
                 */
                case "H":
                case "h": {                    
                    fileByteStream = new FileInputStream("habitat.txt");
                    inFS = new Scanner(fileByteStream);
                        
                    printMenuPrompt("habitat");

                    // Try to open animal.txt file
                    System.out.print("Available habitats for review: ");
                    // print sub menu
                    printSubMenu("habitat");
                                   
                    // line formating obtain user input for habitat lookup
                    System.out.println("");
                    getUserInput = scnr.next();
                        
                    if (getUserInput.equals("B") || getUserInput.equals("b")
                     || getUserInput.equals("E") || getUserInput.equals("e")) {
                        break;
                    }
                    
                    // cycle through file until no more lines and/or data is found
                    while (inFS.hasNext() && !data_found) {
                            
                        // set readLine1 to next line in animal.txt
                        readLine1 = inFS.nextLine();

                        // format user input with capital letter for string comparison
                        capitalizeUserInput = updateCapitalize(getUserInput);

                        // look for lead line of animal data in file, look for user input of animal
                        // name - compares and if found, cycles through lines filling in animalInfo
                        if (readLine1.contains("Habitat - ") && readLine1.contains(capitalizeUserInput)) {
                            // if found, format Habitat - xxxx line then move to next line in file
                            habitatInfo.setField("habitat", readLine1);
                            readLine1 = inFS.nextLine();
                            habitatInfo.setField("temp", readLine1.replace("Temperature: ", ""));
                            readLine1 = inFS.nextLine();

                            // note this does not remove the ***** only the 'Health concerns: ' part
                            // the stars carry over to identify an alert in the AnimalData() method
                            habitatInfo.setField("food", readLine1.replace("Food source: ", ""));
                            readLine1 = inFS.nextLine();

                            habitatInfo.setField("clean", readLine1.replace("Cleanliness: ", ""));

                            // flag data_found to exit while loop and print data to user
                            data_found = true;
                            fileByteStream.close();
                        }
                    }
                    
                    if (habitatInfo.getField("habitat") != null) {

                        if (habitatInfo.alert.alert_found) {
                            alertTitle = habitatInfo.alert.getTitle();
                            alertMessage = habitatInfo.alert.getMessage();
                            System.out.println("Pop up alert!");
                            JOptionPane.showMessageDialog(null, alertMessage, alertTitle, JOptionPane.INFORMATION_MESSAGE);
                            habitatInfo.alert.setAlert(false);
                        }
                        // print out habitatInfo data to user
                        System.out.println(habitatInfo.getField("habitat"));
                        System.out.println("Temperature:   " + habitatInfo.getField("temp"));
                        System.out.println("Food source: \n   " + habitatInfo.getField("food"));
                        System.out.println("Cleanliness: \n   " + habitatInfo.getField("clean"));
                    } 
                    else {
                        // FIXME: add in options to add animals to the database in the future
                        System.out.println("That habitat is not currently registered in the database.");
                    }   
                    // reset loop based values for additional animal lookup sequences
                    data_found = false;
                    getUserInput = "h";
                    break;
                }
                case "B":
                case "b": {
                    printMenuPrompt("main");
                    getUserInput = scnr.next();
                    break;
                }
                default: {
                    System.out.println("Error -> Switch -> Main()");
                    break;
                }
            }
        }
        // confirm program closed - message to user
        System.out.println("Exiting monitoring system now.");
    }
}
